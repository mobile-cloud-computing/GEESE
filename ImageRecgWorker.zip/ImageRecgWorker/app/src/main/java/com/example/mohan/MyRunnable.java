package com.example.mohan;

import android.content.Context;

import java.io.File;

import fi.iki.elonen.NanoHTTPD;

public class MyRunnable implements Runnable {
    Programs prgs;
    Context cont;
    String rest="";
File tfile;
NanoHTTPD.IHTTPSession session;
String res="No";
    public MyRunnable(NanoHTTPD.IHTTPSession session1, File fileName, Context cntx) {
        this.session=session1;
        this.tfile=fileName;
        this.cont=cntx;
    }


    @Override
    public void run() {
        prgs = new Programs(cont,tfile );
        rest=prgs.stat();
        //System.out.println("File name in run "+session.getUri()+"  "+tfile.getName() +" res is "+rest);
        res=rest;
        return;
    }

    public String getRest(){
       // this.res=" ok"+Thread.currentThread().getName();
        return this.res;
    }
}
