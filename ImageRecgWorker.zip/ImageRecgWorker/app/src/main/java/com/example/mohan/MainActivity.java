package com.example.mohan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
//import android.support.v7.app.ActionBarActivity;

import android.os.Looper;
import android.text.format.Formatter;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

import dalvik.system.DexClassLoader;


public class MainActivity extends AppCompatActivity {
    private RestServer1 server1;
    private RestServer server;
    Context context;
    ImageView img;
    TextView tv;
    Button bts;
    /** Web Server port */
    public static final int PORT = 8080;
    private static final int REQUEST_ENABLE_BT = 1;
public Context con=this;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
              setContentView(R.layout.activity_main);
              img=(ImageView)findViewById(R.id.imagePhoto) ;
        tv=(TextView)findViewById(R.id.textView);
        bts=(Button)findViewById(R.id.button_start_service) ;
        this.context=getApplicationContext();
    }
public void stop(View v){
    System.exit(0);
}










    public void buttonStartServiceClicked(View v){
        /*Intent intent = new Intent(this, NanoHttpdService.class);
        intent.putExtra("port", PORT);
        startService(intent);*/

       String ip = getWifiIPAddress();//Util.getIpAddress();

        Thread thread = new Thread() {

            public void run() {

                try {
                    server1= new RestServer1(context);
                    server1.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        };

        thread.start();
       tv.setText(" Worker IP "+ip);
      // bts.setTextColor(Color.GREEN);
        bts.setText("Service Started");
       System.out.println("Server started IP "+ip);
    }

    public void buttonStopServiceClicked(View v){
        Intent intent = new Intent(this, NanoHttpdService.class);
        stopService(intent);
        System.exit(0);
    }

    public String getWifiIPAddress() {
        WifiManager wifiMgr = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        WifiInfo wifiInfo = wifiMgr.getConnectionInfo();
        int ip = wifiInfo.getIpAddress();
        return  Formatter.formatIpAddress(ip);
    }



    /** Thread on which the BT reading runs */




}
