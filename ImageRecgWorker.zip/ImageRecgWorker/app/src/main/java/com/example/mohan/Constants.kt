package com.example.mohan


const val GRAPH_FILE_PATH = "file:///android_asset/mobilenet_v1_1.0_224_quant_frozen.pb"//mobilenet_v1_1.0_224.tflite"//"file:///android_asset/graph.pb"
const val LABELS_FILE_PATH = "file:///android_asset/mobilenet_v1_1.0_224_quant_frozen_labels.txt"
//const val GRAPH_FILE_PATH = "file:///android_asset/mobilenet_v1_1.0_224.tflite"
//const val LABELS_FILE_PATH = "file:///android_asset/labels.txt"

//const val GRAPH_INPUT_NAME = "input"
const val GRAPH_INPUT_NAME = "input"
const val GRAPH_OUTPUT_NAME = "MobilenetV1/Predictions/Reshape_1"//"final_result"

const val IMAGE_SIZE = 224


const val COLOR_CHANNELS = 3

const val ASSETS_PATH = "file:///android_asset/"