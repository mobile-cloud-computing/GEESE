package com.example.mohan


import android.content.Context
import android.content.res.AssetManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Environment
import android.os.Environment.getExternalStorageDirectory
import android.os.Handler
import android.os.Looper

//import com.example.mohan.ble.Sensor;

import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.nio.channels.FileChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.HashMap

import fi.iki.elonen.NanoHTTPD

import com.example.mohan.ASSETS_PATH
import com.example.mohan.GRAPH_FILE_PATH
import com.example.mohan.GRAPH_INPUT_NAME
import com.example.mohan.GRAPH_OUTPUT_NAME
import com.example.mohan.IMAGE_SIZE
import com.example.mohan.LABELS_FILE_PATH
import com.example.mohan.getCroppedBitmap

/**
 * Created by Jakob on 6.02.2015.
 */
class RestServer()//mSensor = new Sensor(context);
    : NanoHTTPD(8080) {
    //private Sensor mSensor;
  //  internal var handler = Handler()

    private val URI_SAMPLE_XML = "/xml"
    private val URI_REQUEST_INFO = "/"
    private val URI_GET_ALTITUDE = "/altitude"
    private val URI_UPLOAD = "/upload"
  //  private val TAG = RestServer1::class.java.name

    // TODO: Allow the user to configure the base path
    private val BASE_SERVE_PATH = ""



    //long millis = System.currentTimeMillis();
    // String time=millis+"";
    val timeData: String
        get() {
            val dNow = Date()
            val dt = SimpleDateFormat("mm_ss")
            val date = dt.format(dNow)
            println("Current Date: $date")

            return date
        }

    @Throws(FileNotFoundException::class)
    override fun serve(session: NanoHTTPD.IHTTPSession): NanoHTTPD.Response {
        val Uri = session.uri
        var responseBody: String
        val method = session.method
        val files = HashMap<String, String>()




        if (Uri == URI_REQUEST_INFO) {
            // return a HTML page showing details of the request (URI, user agents, params, etc)
            responseBody = getRequestDetailsHtml(session)

        } else if (Uri == URI_GET_ALTITUDE) {
            responseBody = java.lang.Float.toString(500f) //TODO: Move this to some service call instead of using it as a field
        } else if (Uri == URI_UPLOAD) {
            // return a HTML page showing details of the request (URI, user agents, params, etc)

            try {

                val sdcard = Environment.getExternalStorageDirectory()
                val dir = File(sdcard.absolutePath + "/Server/")
                dir.mkdir()
                val nfn = timeData
                val fname:String = ""+dir+"/"+nfn+".jpg"
                println("Done download  file  "+fname)
                val dirN = "$dir/"


                responseBody = "Done download  file"

                println("Done download  file  ")
            } catch (e: Exception) {
                println(" Problemsssss   $e")
                responseBody = "Problems in receive file"
            }

        } else {

            responseBody = "Opening dir: "

        }

        return NanoHTTPD.Response(responseBody)
    }


    private fun getRequestDetailsHtml(session: NanoHTTPD.IHTTPSession): String {
        val decodedQueryParameters = decodeParameters(session.queryParameterString)

        val sb = StringBuilder()
        sb.append("<html>")
        sb.append("<head><title>Debug Server</title></head>")
        sb.append("<body>")
        sb.append("<h1>Debug Server</h1>")

        sb.append("<p><blockquote><b>URI</b> = ").append(
                session.uri.toString()).append("<br />")

        sb.append("<b>Method</b> = ").append(
                session.method.toString()).append("</blockquote></p>")

        sb.append("<h3>Headers</h3><p><blockquote>").append(Util.toString(session.headers)).append("</blockquote></p>")

        sb.append("<h3>Parms</h3><p><blockquote>").append(Util.toString(session.parms)).append("</blockquote></p>")

        sb.append("<h3>Parms (multi values?)</h3><p><blockquote>").append(Util.toString(decodedQueryParameters)).append("</blockquote></p>")

        try {
            val files = HashMap<String, String>()
            session.parseBody(files)
            sb.append("<h3>Files</h3><p><blockquote>").append(Util.toString(files)).append("</blockquote></p>")
        } catch (e: Exception) {
            e.printStackTrace()
        }

        sb.append("</body>")
        sb.append("</html>")
        return sb.toString()
    }

    fun cpFile(sourceFile: File, destFile: File): File {
        try {


            if (!destFile.parentFile!!.exists())
                destFile.parentFile!!.mkdirs()

            if (!destFile.exists()) {
                destFile.createNewFile()
            }

            var source: FileChannel? = null
            var destination: FileChannel? = null

            try {
                source = FileInputStream(sourceFile).channel
                destination = FileOutputStream(destFile).channel
                destination!!.transferFrom(source, 0, source!!.size())
            } finally {
                source?.close()
                destination?.close()
            }
        } catch (e: Exception) {
            println(" Problemsssss   $e")

        }

        println("In the copyFile  " + destFile.absolutePath)
        return destFile
    }



}
