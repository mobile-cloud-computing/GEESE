package com.example.mohan

data class Result(val result: String, val confidence: Float)