package com.example.mohan


import android.content.Context

//import android.support.v7.app.ActionBarActivity;


import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Environment

import java.io.File

import android.os.AsyncTask


public class Programs(var cont:Context, tFile:File ){

var tmpF=tFile
    private var photoFilePath = ""
    private lateinit var   classifier: Classifier


    var Message=""

   // private lateinit var croppedBitmap: Bitmap



    public fun stat() :String{



      createClassifier()
  //    println("Done prg  file  "+ tmpF.name)
      //  println("Done prg  file Size "+ tmpF.length())

        var result1 = classifyPhoto(tmpF)
     //   println("Done   result1 "+ result1)
        return result1
    }

    private fun getImage(): File {

        val sdcard = Environment.getExternalStorageDirectory()

        val dir = File(sdcard.absolutePath + "/Client/")

        dir.mkdir()

        val f = "cat.jpg"//.txt";//video.mp3";//TestVid.mp4";
        val fname = "$dir/$f"



        val upf = File(fname)
        //println("upf  $upf")

        return upf
    }


    private fun createClassifier() {

val ast=cont.applicationContext.assets


        classifier = ImageClassifierFactory.create(
                ast,
                GRAPH_FILE_PATH,
                LABELS_FILE_PATH,
                IMAGE_SIZE,
                GRAPH_INPUT_NAME,
                GRAPH_OUTPUT_NAME
        )
    }
    private fun classifyPhoto(file: File) : String{
        val photoBitmap = BitmapFactory.decodeFile(file.absolutePath)
        var croppedBitmap: Bitmap
        croppedBitmap = getCroppedBitmap(photoBitmap)
       // println("croppedBitmap    "+ croppedBitmap.byteCount)
       classifyAndShowResult(croppedBitmap)
     //   println("croppedBitmap    "+ croppedBitmap.byteCount)
       // imagePhoto.setImageBitmap(photoBitmap)
        val result = classifier.recognizeImage(croppedBitmap)
        var  Mess=result.result.toString()
        var con = result.confidence
       // println(" Serv1 Image is "+Mess+"  and Confidence is "+con)
        return Mess+"\t"+con

    }


    private fun classifyAndShowResult(croppedBitmap: Bitmap) {


    }


}