package com.example.mohan;





import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.wifi.WifiManager;
import android.os.Environment;

import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

//import com.example.mohan.ble.Sensor;

import androidx.annotation.UiThread;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import fi.iki.elonen.NanoHTTPD;

import static com.example.mohan.ConstantsKt.ASSETS_PATH;
import static com.example.mohan.ConstantsKt.GRAPH_FILE_PATH;
import static com.example.mohan.ConstantsKt.GRAPH_INPUT_NAME;
import static com.example.mohan.ConstantsKt.GRAPH_OUTPUT_NAME;
import static com.example.mohan.ConstantsKt.IMAGE_SIZE;
import static com.example.mohan.ConstantsKt.LABELS_FILE_PATH;
import static com.example.mohan.ImageUtilsKt.getCroppedBitmap;

/**
 * Created by Jakob on 6.02.2015.
 */
public class RestServer1 extends NanoHTTPD {
    private static final String URI_SAMPLE_XML = "/xml";
    private static final String URI_REQUEST_INFO = "/";
    private static final String URI_GET_ALTITUDE = "/altitude";
    private static final String URI_UPLOAD = "/upload";
    private static final String TAG = RestServer1.class.getName();

    // TODO: Allow the user to configure the base path
    private static String BASE_SERVE_PATH = "";
  //  private final Context context;
Programs prgs;
Context cont;
String rest="";
int fno=0;



    public RestServer1(Context ccntx) {

        super(8080);
        this.cont=ccntx;
        //this.context = context;
        //mSensor = new Sensor(context);
    }

    @Override public Response serve(IHTTPSession session) throws FileNotFoundException {
        String Uri = session.getUri();
        String responseBody;
        Method method = session.getMethod();
        Map<String, String> files = new HashMap<>();




        if (Uri.equals(URI_REQUEST_INFO)){
            // return a HTML page showing details of the request (URI, user agents, params, etc)
            responseBody = getRequestDetailsHtml(session);

        }
        else if (Uri.equals(URI_GET_ALTITUDE)){
            responseBody = Float.toString(500); //TODO: Move this to some service call instead of using it as a field
        }
        else if (Uri.equals(URI_UPLOAD)){
            // return a HTML page showing details of the request (URI, user agents, params, etc)

            try {

               // File sdcard = Environment.getExternalStorageDirectory();
                //File dir = new File(sdcard.getAbsolutePath() + "/Server/");
                //dir.mkdir();
               //String nfn = getTimeData();
                //String fname = dir + "/" + nfn + ".jpg";
                //String dirN=dir+"/";
                String fn=session.getHeaders().get("file");
               // System.out.println("Name  : " + fn);
            //    System.out.println("Target f Name  : " +dir+ fn);

                session.parseBody(files);
                Map<String, String> params = session.getParms();
                for (Map.Entry<String, String> entry : params.entrySet()) {
                    final String paramsKey = entry.getKey();
                    if (paramsKey.contains("image_file_1")) {
                        final String tmpFilePath = files.get(paramsKey);
                        final String fileName = paramsKey;
                        final File tmpFile = new File(tmpFilePath);
                      ///  final File targetFile = new File(fname);
                 //       LogUtil.log("copy file now, source file path: %s,target file path:%s", tmpFile.getAbsoluteFile(), targetFile.getAbsoluteFile());
                        //a copy file method just what you like
                       // cpFile(tmpFile, targetFile);
                        //System.out.println("PKG Name Name  : " + cont.getPackageName());
                        MyRunnable r = new MyRunnable(session,tmpFile,cont);

                        Thread t1 = new Thread(r);

                        t1.start();
                        t1.join();
                        String rr=r.getRest();
                        System.out.println("Got  " + rr);

                        rest=rr;


                     //   rssi();


                    // prgs = new Programs(cont,tmpFile );
                    // rest=prgs.stat();
                      //  System.out.println("Got  " + rest);
                       // createClassifier();

                        //maybe you should put the follow code out
                       // responseBody=("Success");
                    }
                }



             //  responseBody="Done download  file";
                responseBody=rest;



                //System.out.println("Done download  file  " );
            }catch (Exception e){ System.out.println(" Problemsssss   "+e);
                responseBody="Problems in receive file";
            }
        }
        else{

                responseBody = "Opening dir: ";

            }

        return new Response(responseBody);
    }



    public void rssi() {


        File sdcard = Environment.getExternalStorageDirectory();

        File dir = new File(sdcard.getAbsolutePath() + "/RSSI/");
        dir.mkdir();
        File folder=dir;

        Date dNow = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("mm");
        String date = dt.format(dNow);
        String fname = dir + "/" +"0"+ date +"RSSI" +".txt";
        // System.out.println("File created  "+fname);
        File file = new File(fname);
        //    System.out.println("File inside write  " + fname);

        WifiManager wifiManager = (WifiManager) cont.getSystemService(Context.WIFI_SERVICE);
        int rssi1 = wifiManager.getConnectionInfo().getRssi();
        System.out.println("Rssi " + rssi1);

        try {
            FileWriter fr = new FileWriter(file, true);
            fr.write(rssi1 + "\n");
            fr.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



    private String getRequestDetailsHtml(IHTTPSession session) {
        Map<String, List<String>> decodedQueryParameters =
                decodeParameters(session.getQueryParameterString());

        StringBuilder sb = new StringBuilder();
        sb.append("<html>");
        sb.append("<head><title>Debug Server</title></head>");
        sb.append("<body>");
        sb.append("<h1>Debug Server</h1>");

        sb.append("<p><blockquote><b>URI</b> = ").append(
                String.valueOf(session.getUri())).append("<br />");

        sb.append("<b>Method</b> = ").append(
                String.valueOf(session.getMethod())).append("</blockquote></p>");

        sb.append("<h3>Headers</h3><p><blockquote>").
                append(Util.toString(session.getHeaders())).append("</blockquote></p>");

        sb.append("<h3>Parms</h3><p><blockquote>").
                append(Util.toString(session.getParms())).append("</blockquote></p>");

        sb.append("<h3>Parms (multi values?)</h3><p><blockquote>").
                append(Util.toString(decodedQueryParameters)).append("</blockquote></p>");

        try {
            Map<String, String> files = new HashMap<String, String>();
            session.parseBody(files);
            sb.append("<h3>Files</h3><p><blockquote>").
                    append(Util.toString(files)).append("</blockquote></p>");
        } catch (Exception e) {
            e.printStackTrace();
        }

        sb.append("</body>");
        sb.append("</html>");
        return sb.toString();
    }


    public String getTimeData() {
        Date dNow = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("mm_ss");
        String date = dt.format(dNow);
      //  System.out.println("Current Date: " + date);

        //long millis = System.currentTimeMillis();
        // String time=millis+"";

        return date;
    }

    public File cpFile(File sourceFile, File destFile) {
        try{



        if (!destFile.getParentFile().exists())
            destFile.getParentFile().mkdirs();

        if (!destFile.exists()) {
            destFile.createNewFile();
        }

        FileChannel source = null;
        FileChannel destination = null;

        try {
            source = new FileInputStream(sourceFile).getChannel();
            destination = new FileOutputStream(destFile).getChannel();
            destination.transferFrom(source, 0, source.size());
        } finally {
            if (source != null) {
                source.close();
            }
            if (destination != null) {
                destination.close();
            }
        }
    }catch (Exception e){ System.out.println(" Problemsssss   "+e);

        }
     //   System.out.println("In the copyFile  "+destFile.getAbsolutePath());
        return destFile;
    }







}
