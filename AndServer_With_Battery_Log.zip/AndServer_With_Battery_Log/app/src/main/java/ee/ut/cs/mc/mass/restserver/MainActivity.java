package ee.ut.cs.mc.mass.restserver;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
//import android.support.v7.app.ActionBarActivity;

import android.text.format.Formatter;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.model.LatLng;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    /** Web Server port */
    public static final int PORT = 8080;
    private static final int REQUEST_ENABLE_BT = 1;
    private TextView batteryTxt;
    WebServerReceiver webServerReceiver;


    Context context;
    private RestServer1 server1;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                .permitAll().build();
        StrictMode.setThreadPolicy(policy);
        this.context=getApplicationContext();
        tv=(TextView)findViewById(R.id.textView);
        batteryTxt = (TextView) this.findViewById(R.id.textView4);
        this.registerReceiver(this.mBatInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));


    }

    private BroadcastReceiver mBatInfoReceiver = new BroadcastReceiver(){
        @Override
        public void onReceive(Context ctxt, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
            batteryTxt.setText(String.valueOf(level) + "%");
            writeResult(level);
        }
    };

    public  void writeResult(int data){

        try {
            File sdcard = Environment.getExternalStorageDirectory();

            File dir = new File(sdcard.getAbsolutePath() + "/BattData/");
            dir.mkdir();
            Date dNow = new Date();
            SimpleDateFormat ft = new SimpleDateFormat("HH:mm");
            String time = ft.format(dNow);
            //   System.out.println("Current Date: " + fname);

            String fname2 = "BAttValSer" + ".csv";
            // String fname2 = "data.txt";
            File file2 = new File(dir, fname2);

            Writer fileWriter = null;
            BufferedWriter bufferedWriter = null;
            fileWriter = new FileWriter(file2, true);

            bufferedWriter = new BufferedWriter(fileWriter);

            System.out.println("Received time "+data );

            bufferedWriter.append(time+" , "+data+ "\n");
            bufferedWriter.close();

        } catch (Exception ioe) {
            System.out.println("Errors  " + ioe);
        }
    }
    public void stop(View v){
    System.exit(0);
}

    @Override public void onPause() {
        super.onPause();
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            startActivity(new Intent(MainActivity.this,
                    SettingsActivity.class));

            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void buttonStartServiceClicked(View v){
        String ip = getWifiIPAddress();
        tv.setText(" Server IP "+ip);
        this.context=getApplicationContext();
        try {

           server1= new RestServer1(context);
            server1.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void buttonStopServiceClicked(View v){
       // Intent intent = new Intent(this, NanoHttpdService.class);
      //  stopService(intent);

        System.exit(0);
    }






    private class WebServerReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context arg0, Intent arg1) {
            String datapassed = arg1.getStringExtra("MESSAGE");

            TextView textIpaddr = (TextView) findViewById(R.id.textView);
            textIpaddr.setText(datapassed);
        }
    }




    public String getWifiIPAddress() {
        WifiManager wifiMgr = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        WifiInfo wifiInfo = wifiMgr.getConnectionInfo();
        int ip = wifiInfo.getIpAddress();
        return  Formatter.formatIpAddress(ip);
    }
    @Override public void onResume() {
        super.onResume();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

}
