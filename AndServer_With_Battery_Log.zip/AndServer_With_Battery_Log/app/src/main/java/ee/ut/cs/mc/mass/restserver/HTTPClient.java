package ee.ut.cs.mc.mass.restserver;
/**
 * This class deals with general HTTP GET and POST
 * For HTTP GET, use getDataFrom(String urlString) method.
 * This method does not return value, instead
 * the delegate must handle the interface method "processHTTPGETResponse(...)"
 * <p/>
 * For HTTP POST, use postDataTo(...) method.
 * This method returns a String which
 * contains the response message from the end-point.
 * Because it uses <form/> based request,
 * forName is the attribute in the fileUpload form field.
 */


import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by chiichang on 2/06/15.
 */
interface HTTPClientInterface {
    void processResponseMessage(String responseMessage);
    void processHTTPPOSTResponse(String processID, String responseMessage);
    void processHTTPGETResponse(String processID, byte[] responseData);
}


public class HTTPClient {

    static HTTPClientInterface delegate;

    Thread httpClientThread = null;

    static FileOutputStream responseFile;
    static String getfileLocation = "";
    static URL connectURL;
    static String responseString = "";
    static String Title = "title";
    static String Description = "description";
    static String formName = "";
    byte[] dataToServer;

    static byte[] dataFromServer = null;
    //static FileInputStream fileInputStream = null;

    static String iFileName;

    public HTTPClient(HTTPClientInterface theDelegate) {
        delegate = theDelegate;
    }

    public void setDelegate(HTTPClientInterface theDelegate) {
        delegate = theDelegate;
    }


    public void post(final String processID,
                     final String endpointURLString,
                     final String theFormName,
                     final String theFileName,
                     final byte[] postData){

        // make sure thread is free before execution
        if (httpClientThread != null) {
            Log.v("[THREAD STATUS]", "" + httpClientThread.getState().name());
            if (httpClientThread.getState().name().equals("RUNNABLE")) {
                while (httpClientThread.getState().name().equals("RUNNABLE")) {
                    Log.e("[HTTPClient]", "1.Waiting for thread finish...");
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            Log.v("[THREAD STATUS]", "is null.");
        }

        Log.v("[HTTPClient]", "ready...");
        httpClientThread = new Thread(
                new Runnable() {
                    public void run() {
                        HTTPClient.doPost(processID,
                                endpointURLString,
                                theFormName,
                                theFileName,
                                postData);
                    }
                });
        httpClientThread.start();
        while (httpClientThread.getState().name().equals("RUNNABLE")) {
            Log.e("[HTTPClient]", "2.Waiting for thread finish...");
        }
    }

    private static void doPost(final String processID,
                               final String endpointURLString,
                               final String theFormName,
                               final String theFileName,
                               final byte[] postData){

        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";
        String Tag = "fSnd";

        try {
            Log.e(Tag, "Starting Http File Sending to URL");

            URL epURL = new URL(endpointURLString);

            // Open a HTTP connection to the URL
            HttpURLConnection conn = (HttpURLConnection) epURL.openConnection();

            // Allow Inputs
            conn.setDoInput(true);

            // Allow Outputs
            conn.setDoOutput(true);

            // Don't use a cached copy.
            conn.setUseCaches(false);

            // Use a post method.
            conn.setRequestMethod("POST");

            conn.setRequestProperty("Connection", "Keep-Alive");

            conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);

            DataOutputStream dos = new DataOutputStream(conn.getOutputStream());

            dos.writeBytes(twoHyphens + boundary + lineEnd);
            dos.writeBytes("Content-Disposition: form-data; name=\"title\"" + lineEnd);
            dos.writeBytes(lineEnd);
            dos.writeBytes(Title);
            dos.writeBytes(lineEnd);
            dos.writeBytes(twoHyphens + boundary + lineEnd);

            dos.writeBytes("Content-Disposition: form-data; name=\"description\"" + lineEnd);
            dos.writeBytes(lineEnd);
            dos.writeBytes(Description);
            dos.writeBytes(lineEnd);
            dos.writeBytes(twoHyphens + boundary + lineEnd);

            dos.writeBytes("Content-Disposition: form-data; name=\"" + theFormName + "\";filename=\"" + theFileName + "\"" + lineEnd);
            dos.writeBytes(lineEnd);

            Log.e(Tag, "Headers are written");

            InputStream theInputStream = new ByteArrayInputStream(postData);

            // create a buffer of maximum size
            int bytesAvailable = theInputStream.available();

            int maxBufferSize = 1024;
            int bufferSize = Math.min(bytesAvailable, maxBufferSize);
            byte[] buffer = new byte[bufferSize];

            // read file and write it into form...
            int bytesRead = theInputStream.read(buffer, 0, bufferSize);

            while (bytesRead > 0) {
                dos.write(buffer, 0, bufferSize);
                bytesAvailable = theInputStream.available();
                bufferSize = Math.min(bytesAvailable, maxBufferSize);
                bytesRead = theInputStream.read(buffer, 0, bufferSize);
            }
            dos.writeBytes(lineEnd);
            dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

            // close streams
            theInputStream.close();

            dos.flush();

            Log.e("[EE]", "File Sent, Response: " + String.valueOf(conn.getResponseCode()));

            InputStream is = conn.getInputStream();

            // retrieve the response from server
            int ch;

            StringBuffer b = new StringBuffer();
            while ((ch = is.read()) != -1) {
                b.append((char) ch);
            }
            String s = b.toString();
//            Log.i(">>>Response",s);
            responseString = s;


            dos.close();

            //call delegate method
//            delegate.processResponseMessage(responseString);
            delegate.processHTTPPOSTResponse(processID, responseString);

        } catch (MalformedURLException ex) {
            Log.e(Tag, "URL error: " + ex.getMessage(), ex);
        } catch (IOException ioe) {
            Log.e(Tag, "IO error: " + ioe.getMessage(), ioe);
        }
    }


    public void postDataTo(final String processID, URL serverURL, String theFormName, String theFileName, final FileInputStream theFileInputStream) {
        connectURL = serverURL;
        formName = theFormName;
        iFileName = theFileName;
        //fileInputStream = theFileInputStream;

        Log.v("[HTTPClient]", "fileInputStream=" + theFileInputStream.toString());

        if (httpClientThread != null) {
            Log.v("[THREAD STATUS]", "" + httpClientThread.getState().name());
            if (httpClientThread.getState().name().equals("RUNNABLE")) {
                while (httpClientThread.getState().name().equals("RUNNABLE")) {
                    Log.e("[HTTPClient]", "1.Waiting for thread finish...");
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            Log.v("[THREAD STATUS]", "is null.");
        }

        Log.v("[HTTPClient]", "ready...");
        httpClientThread = new Thread(
                new Runnable() {
                    public void run() {
                        HTTPClient.doPost(processID, theFileInputStream);
                    }
                });
        httpClientThread.start();
        while (httpClientThread.getState().name().equals("RUNNABLE")) {
            Log.e("[HTTPClient]", "2.Waiting for thread finish...");
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
//        return responseString;
    }

    private static void doPost(String processID, FileInputStream fileInputStream) {
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";
        String Tag = "fSnd";
        try {
            Log.e(Tag, "Starting Http File Sending to URL");

            // Open a HTTP connection to the URL
            HttpURLConnection conn = (HttpURLConnection) connectURL.openConnection();

            // Allow Inputs
            conn.setDoInput(true);

            // Allow Outputs
            conn.setDoOutput(true);

            // Don't use a cached copy.
            conn.setUseCaches(false);

            // Use a post method.
            conn.setRequestMethod("POST");

            conn.setRequestProperty("Connection", "Keep-Alive");

            conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);

            DataOutputStream dos = new DataOutputStream(conn.getOutputStream());

            dos.writeBytes(twoHyphens + boundary + lineEnd);
            dos.writeBytes("Content-Disposition: form-data; name=\"title\"" + lineEnd);
            dos.writeBytes(lineEnd);
            dos.writeBytes(Title);
            dos.writeBytes(lineEnd);
            dos.writeBytes(twoHyphens + boundary + lineEnd);

            dos.writeBytes("Content-Disposition: form-data; name=\"description\"" + lineEnd);
            dos.writeBytes(lineEnd);
            dos.writeBytes(Description);
            dos.writeBytes(lineEnd);
            dos.writeBytes(twoHyphens + boundary + lineEnd);

            dos.writeBytes("Content-Disposition: form-data; name=\"" + formName + "\";filename=\"" + iFileName + "\"" + lineEnd);
            dos.writeBytes(lineEnd);

            Log.e(Tag, "Headers are written");

            // create a buffer of maximum size
            int bytesAvailable = fileInputStream.available();

            int maxBufferSize = 1024;
            int bufferSize = Math.min(bytesAvailable, maxBufferSize);
            byte[] buffer = new byte[bufferSize];

            // read file and write it into form...
            int bytesRead = fileInputStream.read(buffer, 0, bufferSize);

            while (bytesRead > 0) {
                dos.write(buffer, 0, bufferSize);
                bytesAvailable = fileInputStream.available();
                bufferSize = Math.min(bytesAvailable, maxBufferSize);
                bytesRead = fileInputStream.read(buffer, 0, bufferSize);
            }
            dos.writeBytes(lineEnd);
            dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

            // close streams
            fileInputStream.close();

            dos.flush();

            Log.e("[EE]", "File Sent, Response: " + String.valueOf(conn.getResponseCode()));

            InputStream is = conn.getInputStream();

            // retrieve the response from server
            int ch;

            StringBuffer b = new StringBuffer();
            while ((ch = is.read()) != -1) {
                b.append((char) ch);
            }
            String s = b.toString();
//            Log.i(">>>Response",s);
            responseString = s;


            dos.close();

            //call delegate method
//            delegate.processResponseMessage(responseString);
            delegate.processHTTPPOSTResponse(processID, responseString);

        } catch (MalformedURLException ex) {
            Log.e(Tag, "URL error: " + ex.getMessage(), ex);
        } catch (IOException ioe) {
            Log.e(Tag, "IO error: " + ioe.getMessage(), ioe);
        }
    }

    public void getDataFrom(final String processID, final String urlString) throws Exception {

        // Make sure the previous process has finished before the new process execution
        if (httpClientThread != null) {
            Log.v("[THREAD STATUS]", "" + httpClientThread.getState().name());
            if (httpClientThread.getState().name().equals("RUNNABLE")) {
                while (httpClientThread.getState().name().equals("RUNNABLE")) {
                    Log.e("[HTTPClient]", "1.Waiting for thread finish...");
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            Log.v("[THREAD STATUS]", "is null.");
        }

        Log.v("[HTTPClient]", "ready...");
        httpClientThread = new Thread(
                new Runnable() {
                    public void run() {
                        HTTPClient.doGET(processID, urlString);
                    }
                });
        httpClientThread.start();
//        Log.e("[THREAD_STATUS]", httpClientThread.getState().name());
//        while (!httpClientThread.getState().name().equals("TERMINATED")) {
//            Log.e("[HTTPClient]", "2.Waiting for thread finish...");
//        }
    }

    private static void doGET(String processID, String urlString) {
        Log.e("[HTTPClient]", "doGET executed...");

        //** identify the fileName from the urlString
//        String filename=urlString.substring(urlString.lastIndexOf("/")+1);

        try {
            URL theURL = new URL(urlString);
            HttpURLConnection httpConn = (HttpURLConnection) theURL.openConnection();
            int responseCode = httpConn.getResponseCode();

            // always check HTTP response code first
            if (responseCode == HttpURLConnection.HTTP_OK) {
                HttpURLConnection urlConnection = (HttpURLConnection) theURL.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setDoOutput(true);
                urlConnection.connect();

//                File thePATH = new File(Environment.getExternalStorageDirectory().toString() + "/Download/");
//                File file = new File(thePATH, filename);
//
//                FileOutputStream fileOutput = new FileOutputStream(file);

                ByteArrayOutputStream fileOutput = new ByteArrayOutputStream();

                InputStream inputStream = urlConnection.getInputStream();

                int totalSize = urlConnection.getContentLength();

                int downloadedSize = 0;

                byte[] buffer = new byte[1024];

                int bufferLength = 0; //used to store a temporary size of the buffer

                while ((bufferLength = inputStream.read(buffer)) > 0)
                {

                    //add the data in the buffer to the file in the file output stream (the file on the sd card

                    fileOutput.write(buffer, 0, bufferLength);

                    //add up the size so we know how much is downloaded

                    downloadedSize += bufferLength;

                    int progress = (int) (downloadedSize * 100 / totalSize);

                    //this is where you would do something to report the prgress, like this maybe

                    //updateProgress(downloadedSize, totalSize);

                }

                fileOutput.close();

                dataFromServer = fileOutput.toByteArray();

                delegate.processHTTPGETResponse(processID, fileOutput.toByteArray());

                Log.v("[HTTPClient]", "File size=" + fileOutput.toByteArray().length);

                Log.v("[HTTPClient]", "File downloaded");
            } else {
                Log.v("[HTTPClient]", "No file to download. Server replied HTTP code: " + responseCode);
            }
            httpConn.disconnect();


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//    public String getDataFrom(final String urlString) throws Exception{
//        if (httpClientThread != null){
//            Log.v("[THREAD STATUS]", ""+httpClientThread.getState().name());
//            if(httpClientThread.getState().name().equals("RUNNABLE")){
//                while (httpClientThread.getState().name().equals("RUNNABLE")) {
//                    Log.e("[HTTPClient]", "1.Waiting for thread finish...");
//                    try {
//                        Thread.sleep(5000);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        }else{
//            Log.v("[THREAD STATUS]", "is null.");
//        }
//
//        Log.v("[HTTPClient]", "ready...");
//        httpClientThread = new Thread(
//                new Runnable() {
//                    public void run() {
//                        HTTPClient.doGET(urlString);
//                    }
//                });
//        httpClientThread.start();
//        while (httpClientThread.getState().name().equals("RUNNABLE")) {
//            Log.e("[HTTPClient]", "2.Waiting for thread finish...");
//        }
//        return getfileLocation;
//    }
//
//    private static final int BUFFER_SIZE = 4096;
//
//    private static void doGET(String urlString) {
//
//        String filename=urlString.substring(urlString.lastIndexOf("/")+1);

//        getfileLocation = Environment.getExternalStorageDirectory().toString()+"/Download/" + filename;
//
//        FileOutputStream outputStream = null;
//
//        URL theURL = null;
//        try {
//            theURL = new URL(urlString);
//            HttpURLConnection httpConn = (HttpURLConnection) theURL.openConnection();
//            int responseCode = httpConn.getResponseCode();
//
//            // always check HTTP response code first
//            if (responseCode == HttpURLConnection.HTTP_OK) {
//                HttpURLConnection urlConnection = (HttpURLConnection) theURL.openConnection();
//                urlConnection.setRequestMethod("GET");
//                urlConnection.setDoOutput(true);
//                urlConnection.connect();
//
//
//
//                File thePATH = new File(Environment.getExternalStorageDirectory().toString()+"/Download/");
//                File file = new File(thePATH, filename);
//
//                FileOutputStream fileOutput = new FileOutputStream(file);
//
//                InputStream inputStream = urlConnection.getInputStream();
//
//                int totalSize = urlConnection.getContentLength();
//
//                int downloadedSize = 0;
//
//                byte[] buffer = new byte[1024];
//
//                int bufferLength = 0; //used to store a temporary size of the buffer
//
//                while ( (bufferLength = inputStream.read(buffer)) > 0 )
//
//                {
//
//                    //add the data in the buffer to the file in the file output stream (the file on the sd card
//
//                    fileOutput.write(buffer, 0, bufferLength);
//
//                    //add up the size so we know how much is downloaded
//
//                    downloadedSize += bufferLength;
//
//                    int progress=(int)(downloadedSize*100/totalSize);
//
//                    //this is where you would do something to report the prgress, like this maybe
//
//                    //updateProgress(downloadedSize, totalSize);
//
//                }
//
//                fileOutput.close();
//
//                responseFile = fileOutput;
//
//                Log.v("[HTTPClient]", "File downloaded");
//            } else {
//                Log.v("[HTTPClient]", "No file to download. Server replied HTTP code: " + responseCode);
//            }
//            httpConn.disconnect();
//
//
//        } catch (MalformedURLException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//
//    }
}
