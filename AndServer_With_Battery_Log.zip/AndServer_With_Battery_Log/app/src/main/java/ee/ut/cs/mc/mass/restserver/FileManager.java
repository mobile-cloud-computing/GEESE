package ee.ut.cs.mc.mass.restserver;


import android.os.Environment;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by chiichang on 3/06/15.
 */
public class FileManager {

    final File appDirectory = new File(Environment.getExternalStorageDirectory().toString() + "/CoapServer/");

    public FileManager() {
        createDir();
    }

    public void createDir() {
        if (!appDirectory.exists()) {
            appDirectory.mkdirs();
        }
    }

    public void putFile(String fileName, byte[] theFile) {
        File file = new File(appDirectory, fileName);

        if(file.exists()){
            file.delete();
        }

        try {
            FileOutputStream fos=new FileOutputStream(file.getPath());
            fos.write(theFile);
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public FileInputStream getFileAsFileInputStream(final String filePathWithFileName){
        FileInputStream fstrm = null;
        try {
            fstrm = new FileInputStream(Environment.getExternalStorageDirectory().toString() + filePathWithFileName);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return fstrm;
    }

    public byte[] getFileAsByteArray(final String filePathWithFileName){

        //System.out.println(file.exists() + "!!");
        //InputStream in = resource.openStream();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[1024];
        try {

            FileInputStream fstrm = new FileInputStream(Environment.getExternalStorageDirectory().toString() + filePathWithFileName);

            for (int readNum; (readNum = fstrm.read(buf)) != -1;) {
                bos.write(buf, 0, readNum); //no doubt here is 0
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return bos.toByteArray();
    }
}
