package ee.ut.cs.mc.mass.restserver;


import android.content.Context;
import android.location.Location;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Environment;
import android.os.Looper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fi.iki.elonen.NanoHTTPD;

import static android.content.Context.BATTERY_SERVICE;

//import com.example.mohan.ble.Sensor;

/**
 * Created by Jakob on 6.02.2015.
 */
public class RestServer1 extends NanoHTTPD {
    private static final String URI_SAMPLE_XML = "/xml";
    private static final String URI_REQUEST_INFO = "/";
    private static final String URI_GET_ALTITUDE = "/altitude";
    private static final String URI_UPLOAD = "/upload";
    private static final String TAG = RestServer1.class.getName();

    // TODO: Allow the user to configure the base path
    private static String BASE_SERVE_PATH = "";
  //  private final Context context;
  Location locc,cont2;
  Context conx;
String rest="";
int fno=0;
    String httpRes = "  ";
    String responseBody = "";
    int step=0;
    double latitude = 0, longitude = 0;
    long elapsed = 0, start = 0, end = 0;



    public RestServer1(Context conxx) {

        super(8080);
        this.conx=conxx;
        //this.context = context;
        //mSensor = new Sensor(context);
    }

    @Override
    public Response serve(IHTTPSession session) throws FileNotFoundException {
        String Uri = session.getUri();
        String responseBody;
        Method method = session.getMethod();
      //  Map<String, String> files = new HashMap<>();
        Map<String, String> files = new HashMap<String, String>();



        if (Method.GET.equals(method)) {
            Looper.prepare();

        //    System.out.println("Method  is  " + method);


       //     System.out.println("Context  is  " + conx);
           /* GPSTracker currentGPS=new GPSTracker(conx);
            Location location = currentGPS.getLocation();
            double lat=location.getLatitude();
            double logn =location.getLongitude();*/
       //     System.out.println("Location is   " +lat +"  " +logn);
           //TrackLocation currentGPS= new TrackLocation(conx);

            responseBody ="From get";

        }


        else if (Uri.equals(URI_UPLOAD)){
            // return a HTML page showing details of the request (URI, user agents, params, etc)

            try {
               // Looper.prepare();
              /*  BatteryManager bm = (BatteryManager) conx.getSystemService(BATTERY_SERVICE);
                int batLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);


                System.out.println("Bat Level   " +batLevel);
*/
                /*String fn=session.getHeaders().get("file");
                session.parseBody(files);

                String postParameter = session.getParms().get("val");

                System.out.println("Array is  " + postParameter);

                GPSTracker currentGPS=new GPSTracker(conx);
                Location location = currentGPS.getLocation();
                double lat=location.getLatitude();
                double logn =location.getLongitude();
                //     System.out.println("Location is   " +lat +"  " +logn);
                //TrackLocation currentGPS= new TrackLocation(conx);*/

                responseBody = primes(session,files);//("Location : latitude "+lat+" Longitude: "+logn+" Step "+postParameter);


               // responseBody = Bubble(session,files);

                //System.out.println("Done download  file  " );
            }catch (Exception e){ System.out.println(" Problemsssss   "+e);
                responseBody="Problems in receive file";
            }
        }
        else{

                responseBody = "Opening dir: ";

            }

        return new Response(responseBody);
    }




    public String  Bubble (IHTTPSession session ,  Map<String, String> files ){
        String reply="From Bubble";
        try {
        session.parseBody(files);

        String postParameter = session.getParms().get("val");
            String Ary= session.getParms().get("arry");
     //   System.out.println("Loop is  " + postParameter);
         //   System.out.println("Arry  " + Ary);

            String[] values = Ary.split(",");
            int ss=values.length;
            System.out.println("Arry  size" + ss);
            int[] vals=new int[ss];
int ans=0;
            for(int x=0;x<ss;x++){
               // System.out.println("Arrayy is "+values[x]);//vals[x]=Integer.getInteger(values[x]);
                vals[x]=Integer.parseInt(values[x]);
               // System.out.println("Integer Arrayy is "+vals[x]);
            }


                for (int i = 0; i < ss-1; i++)
                    for (int j = 0; j < ss-i-1; j++)
                        if (vals[j] > vals[j+1])
                        {
                            // swap temp and arr[i]
                            int temp = vals[j];
                            vals[j] = vals[j+1];
                            vals[j+1] = temp;
                        }

           for(int p=0;p<ss;p++){
                ans=ans+vals[p];
            }

            //   for(int x=0;x<ss;x++){}
            reply="Done Bubble , "+postParameter+" , ";
        }catch (Exception e){ System.out.println(" Problemsssss   "+e);
            reply="Problems in receive file";
        }
        return reply;
    }

    public String  factori (IHTTPSession session ,  Map<String, String> files ){
        String reply="From Factorial";
        String fct="";
        String postParameter="";
        try {
        session.parseBody(files);


         postParameter = session.getParms().get("val");
        String Ary= session.getParms().get("arry");
        int number=Integer.parseInt(Ary);
         //   System.out.println("Number is "+number);

        for (int loopCounter = 1; loopCounter <= number; loopCounter++) {
          //  System.out.println("check the number");// check if remainder of division is 0
            if (number % loopCounter == 0) {
                System.out.println(loopCounter + " ");
                fct=fct+" "+loopCounter;

            }
        }
        }catch (Exception e){ System.out.println(" Problemsssss   "+e);
            reply="Problems in receive file";
        }
        //System.out.println("Ans is "+fct);
            return reply+" " +postParameter+fct;
    }

    public String  primes (IHTTPSession session ,  Map<String, String> files ){

        String reply="From Prime";
        String isprime=" dont Prime";
        String postParameter="";
        try {
            session.parseBody(files);

             postParameter = session.getParms().get("val");
            String Ary= session.getParms().get("arry");
            //   System.out.println("Loop is  " + postParameter);
            //   System.out.println("Arry  " + Ary);

            String[] values = Ary.split(",");
            int ss=values.length;
           // System.out.println("Arry  size" + ss);
            int[] vals=new int[ss];
            int ans=0;

            for(int x=0;x<ss;x++){
                // System.out.println("Arrayy is "+values[x]);//vals[x]=Integer.getInteger(values[x]);
                vals[x]=Integer.parseInt(values[x]);
                System.out.println("Integer Arrayy is "+vals[x]);
            }

for (int k=0;k<ss;k++) {
    isprime=" dont Prime";

    if (vals[k] % 2 == 0) {isprime = vals[k]+ " false "; System.out.println(isprime);}



    for (int p = 3; p * p <= vals[k]; p += 2) {
        if (vals[k] % p == 0)
            isprime = vals[k]+" false ";
       // System.out.println(isprime);
    }

    isprime =vals[k]+ " true ";
   // System.out.println(isprime);

}

        }catch (Exception e){ System.out.println(" Problemsssss   "+e);
            reply="Problems in receive file";
        }

            //check if n is a multiple of 2

            //if not, then just check the odds




        System.out.println("sending  3" +isprime);


        return postParameter+" "+isprime;
    }

}
