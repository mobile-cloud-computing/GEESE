import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class getClient {
	 private static final String IMGUR_CLIENT_ID = "...";
	    private static final MediaType MEDIA_TYPE_PNG = MediaType.parse("image/png");
	   private final OkHttpClient client = new OkHttpClient();
	    long toTime=0;

	    public void startGet(int val, int siz) {
	    	

	        String server ="http://192.168.0.103:8080/upload";// Replace with the server IP";


	        try {
			
			
			 OkHttpClient client = new OkHttpClient.Builder() .connectTimeout(5,TimeUnit.SECONDS)
			 
			 .build();
			 
			 



	String val2=Integer.toString(val);
	            
	          RequestBody formBody = new FormBody.Builder()
	                    .add("val",val2)
	                    .add("arry", "104549,104551,104561,104579,104593,104597,104623,104639,104651,104659,104677,104681,104683,104693,104701,104707,104711,104717,104723,104729")
	                    .build();
	          

	            Request request = new Request.Builder()
	                    .url(server)
	                    .post(formBody)
	                    .build();
	            long startT = System.currentTimeMillis();

	            Response response = client.newCall(request).execute();
	          //  if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

	            Headers responseHeaders = response.headers();
	            for (int i = 0; i < responseHeaders.size(); i++) {
	                //  System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
	            }
	            String gotData = response.body().string();
	           // System.out.println("Got data " + gotData);




	            long recvTime=System.currentTimeMillis();
	             toTime  =recvTime-startT;

	            String outst=gotData+" Time , "+toTime;
	           System.out.println("Received  "+outst );
	           
			
			 

	        } catch (Exception ioe) {
	            System.out.println("Errors  " + ioe);
	        }


	    }
	    public long getTim(){
	        return toTime;
	    }

}
