import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class OkHttpExample1 {

    // only one client, singleton, better puts it in a factory,
	// multiple instances will create more memory.
    private final static OkHttpClient httpClient = new OkHttpClient();

    public static void main(String[] args) throws IOException {
    	int i=0;
        int count=1;
        int size=70;
        int j=0;
//for ( j=0;j<(1000/size);j++) {
      while (true) {
            for (i = 0; i < size; i++) {

                passData(i,size);
                System.out.println("********** Done ***********  " + i);
/*
            getClient gcl = new getClient();
            gcl.startGet();
            System.out.println("********** Done ***********  " + i);*/

			/*
			 * try { Thread.sleep(3); } catch (InterruptedException e) {
			 * e.printStackTrace(); }
			 */
			 
       count++;

        }
           j++;
		/*
		 * System.out.println("********** Finish round **********  "+j);
		 * 
		  try { Thread.sleep(10); } catch (InterruptedException e) {
		 * e.printStackTrace(); }
		 */
           try { Thread.sleep(5000); } catch (InterruptedException e) {
      		  e.printStackTrace(); }

			
			  Date dNow = new Date(); SimpleDateFormat ft = new SimpleDateFormat("HH:mm");
			  String time = ft.format(dNow);
			  
			  FileWriter writer = new FileWriter("C:\\ResearchWork\\UAV_Paper_April_2020\\Test\\ServerLoadAndroid\\"+"time.csv",true); writer.write(time+"\n"); writer.close();
			 
            System.out.println("********** Finish************************************************************************ ***********  "+j);
     }

    }
    
    public static void passData(final int x, final int y) {
        Thread thread = new Thread() {
            long tot;
            public void run() {
              

                getClient gcl = new getClient();
                gcl.startGet(x,y);
                tot =gcl.getTim();
                String msgn=Long.toString(tot);
              
            }
        };
        thread.start();
    }
    
    
    

}